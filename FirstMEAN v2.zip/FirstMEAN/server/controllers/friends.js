console.log('friends controller');
// WE NEED TO ADD A FEW lines of code here!
var mongoose = require('mongoose');
Friend = mongoose.model("Friend");

function FriendsController(){
  this.index = function(req,res){
    Friend.find( {}, function(err, friends) {
        if(err) {
            console.log("You really suck at this.");
        } else {
            res.json({friends: friends});
        }
    });
  };
  this.create = function(req,res){
    //   friend = mongoose.model("friend").find({name: "oscar"})
      res.json({friend: friend})
    //your code here
    res.json({placeholder:'create'});
  };
  this.update = function(req,res){
    //your code here
    res.json({placeholder:'update'});
  };
  this.delete = function(req,res){
    //your code here
    res.json({placeholder:'delete'});
  };
  this.show = function(req,res){
    //your code here
    res.json({placeholder:'show'});
  };
}
module.exports = new FriendsController(); // what does this export?
